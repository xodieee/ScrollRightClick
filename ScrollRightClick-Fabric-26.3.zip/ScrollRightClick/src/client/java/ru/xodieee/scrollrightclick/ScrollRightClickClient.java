package ru.xodieee.scrollrightclick;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;

public final class ScrollRightClickClient implements ClientModInitializer {
    private static boolean releaseUseKeyNextTick = false;

    @Override
    public void onInitializeClient() {
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (releaseUseKeyNextTick) {
                client.options.keyUse.setDown(false);
                releaseUseKeyNextTick = false;
            }
        });
    }

    public static void triggerRightClick() {
        Minecraft client = Minecraft.getInstance();

        // Do not turn scrolling in menus or inventory screens into item use.
        if (client == null || client.screen != null || client.player == null || client.level == null) {
            return;
        }

        client.options.keyUse.setDown(true);
        releaseUseKeyNextTick = true;
    }
}
