package ru.xodieee.scrollrightclick.mixin;

import net.minecraft.client.MouseHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.xodieee.scrollrightclick.ScrollRightClickClient;

@Mixin(MouseHandler.class)
public abstract class MouseHandlerMixin {
    @Inject(method = "onScroll", at = @At("HEAD"))
    private void scrollrightclick$onScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (vertical != 0.0) {
            ScrollRightClickClient.triggerRightClick();
        }
    }
}
